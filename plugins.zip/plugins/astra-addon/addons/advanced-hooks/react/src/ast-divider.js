/**
 * Divider component.
 */
const Divider = () => (
	<div className='ast-cl-settings-divider' />
)

export default Divider
