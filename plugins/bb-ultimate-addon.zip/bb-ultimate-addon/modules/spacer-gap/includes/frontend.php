<?php
/**
 *  UABB Spacer Gap Module front-end file
 *
 *  @package UABB Spacer Gap Module
 */

?>
<?php /* HTML Markup */ ?>
<div class="uabb-module-content uabb-spacer-gap-preview uabb-spacer-gap">
</div>
