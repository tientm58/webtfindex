<?php
/**
 *  Frontend php file for Business Review module.
 *
 *  @package UABB Business Review file Frontend.php file
 */

echo wp_kses_post( $module->render() );


