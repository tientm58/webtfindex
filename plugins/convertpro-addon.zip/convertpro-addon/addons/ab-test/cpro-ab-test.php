<?php
/**
 * Convert Pro Addon A/B Test loader file
 *
 * @package Convert Pro Addon
 * @author Brainstorm Force
 */

// Prohibit direct script loading.
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

require_once 'classes/class-cpro-abtest-loader.php';
