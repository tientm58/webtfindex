<?php
/**
 * Convert Pro Addon Connects loader file
 *
 * @package Convert Pro Addon
 * @author Brainstorm Force
 */

// Prohibit direct script loading.
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

require_once 'classes/class-cp-v2-services-loader.php';
