<?php
/**
 * Fields.
 *
 * @package ConvertPro
 */

$text_attributes = array(
	'id'      => 'cp_dropdown_par',
	'type'    => 'dropdown',
	'scripts' => '',
	'styles'  => '',
);

echo wp_json_encode( $text_attributes );
