<?php
/**
 * Fields.
 *
 * @package ConvertPro
 */

$text_attributes = array(
	'id'      => 'cp_text_align_par',
	'type'    => 'text_align',
	'scripts' => 'text_align.js',
	'styles'  => '',
);
echo wp_json_encode( $text_attributes );
