<?php

require_once ('custom-post/tfindex.php');
require_once ('custom-post/tftalk.php');
require_once ('custom-post/chart.php');
require_once ('custom-post/testimonials.php');
require_once ('custom-post/staff.php');
